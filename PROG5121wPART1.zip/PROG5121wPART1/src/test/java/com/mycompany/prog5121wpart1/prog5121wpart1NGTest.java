/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.prog5121wpart1;

import static org.testng.Assert.*;

/**
 *
 * @author Titus
 */
public class prog5121wpart1NGTest {
    
    public prog5121wpart1NGTest() {
    }
    
}
