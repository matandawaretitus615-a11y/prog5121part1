/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.prog5121wpart1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Titus
 */
public class LoginIT {
    
    public LoginIT() {
    }

    @Test
    public void testGetUsername() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
