/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.prog5121wpart1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Titus
 */
public class prog5121wpart1IT {
    
    public prog5121wpart1IT() {
    }

    @Test
    public void testMain() {
    }
    
}
