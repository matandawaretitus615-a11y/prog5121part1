/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121wpart1;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Titus
 */
public class prog5121wpart1 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        ArrayList<Login> users = new ArrayList<>(); //store multiple users
        
        System.out.println("\n Welcome to our chatapp version26 ,please choose an option!");
        
        while (true) {
            //Display the menu after each action
            System.out.println("\n Main menu :");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("please choose an option: ");
            
            if(scanner.hasNextInt()) {
                int choice = scanner.nextInt();
            }else {
                System.out.println("please enter a number (1-3)");
                scanner.nextLine();//clear valid input
                continue;
            }
            int choice = 0;
            
            switch(choice) {
                case 1 -> {
                    //regisration
                    System.out.print("Enter username:");
                    String username = scanner.nextLine();
                    System.out.println("Username is successfully captured!");
                    //validate the username
                    boolean validUsername = username.contains("_")&&username.length()<=5;
                    if(!validUsername) {
                        System.out.println("username must contain at least one underscore(_)and must be no longer than 5 characters");
                        break;
                    }
                    System.out.print("Enter password");
                    String password = scanner.nextLine();
                    System.out.println("password successfully captured!");
                    //validation of password
                    boolean validPassword = password.length()>=8 && password.matches(".*[A-Z].*") &&password.matches(".*\\d.*") &&
                            password.matches(".*[!@#$%^&*()\\-={}\\[\\]:;\"<>,./].*");
                    if(!validPassword) {
                        System.out.println("password must be at least 8 characters long,contain a uppercase and lowercase letter,number and special characters");
                        break;
                    }
                    System.out.print("Enter your south african phone number :(e.g. +27823333333");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("cellphone number successfully added!");
                    //validation of cellphne number.
                    String regex = "\\+27[6-8]\\d{8}";
                    if(!phoneNumber.matches(regex)) {
                        System.out.println("Invalid phone number format! use format +27xxxxxxxxx");
                        break;
                    }
                    //check if the user already exists.
                    boolean userExists = users.stream().anyMatch(u ->u.getUsername().equals(username));
                    if(userExists) {
                        System.out.println("Username already exists, please choose another username");
                        break;
                    }
                    //add a new user.
                    users.add(new Login(username,password,phoneNumber));
                    System.out.println("User is registered successfully!");
                    
                    //welcome the user and transition to login.
                    System.out.println("welcome" + username +"you now can login!");
                    System.out.println("Redirecting you back to the login page ...\n");
                    
                    //immediately ask the user to login
                    promptLogin(scanner, users);
                }
                    
                case 2 -> {
                    //Login
                    if(users.isEmpty()) {
                        System.out.println("No users registered. Please register first");
                        break;
                    }
                    //prompt user to login
                    promptLogin(scanner, users);
                }
                        
                case 3 -> {
                    //Exit
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
                }
                    
                default -> System.out.println("Invalid option,please select option 1,2 or 3");
            }       
                    
            
        } 
    }
//method to handle login
    private static void promptLogin(Scanner scanner,ArrayList<Login>users) {
        System.out.print("Enter username:");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password:");
        String enteredPassword = scanner.nextLine();
        //find user and attempt to login
        Login user = users.stream().filter(u->u.getUsername().equals(enteredUsername)).findFirst().orElse(null);
        
        boolean loginStatus = user != null && user.loginUser(enteredPassword);
        System.out.println(user !=null? user.returnLoginStatus(loginStatus) : "user not found");
        
    }
    
}
//login class
class Login {
    public String username;
    public String passwordHash;
    public String phoneNumber;
    public byte[]salt;
    
    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;   
    }
    public String getUsername() {
        return username;
    }
    public boolean loginUser(String enteredPassword) {
        return this.passwordHash.equals(hashPassword(enteredPassword, salt));
    }
    public String returnLoginStatus(boolean status) {
        return status?"Login successfull! ":"invalid username or password";  
    }
    //hash password with salt using SHA-256
    private String hashPassword(String password, byte[]salt){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);//add salt to the hash
            byte[]hash=md.digest(password.getBytes());
            StringBuilder hexString= new StringBuilder();
            for(byte b: hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        }catch(NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    //generate a random salt for password hashhing
    private byte[]generateSalt() {
        try{
            SecureRandom random = new SecureRandom();
            byte[]salt=new byte[16];
            random.nextBytes(salt);
            return salt;
            
        }catch (Exception e) {
            throw new RuntimeException("Error generating",e);
        }
    }
}